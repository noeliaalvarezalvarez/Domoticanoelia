
const char* temperatura_topic = "casa/sensores/temperatura12";
const char* humidade_topic = "casa/sensores/humidade12";
const char* depuracion_topic = "depuracion12";  
const char* rele_topic = "casa/actuadores/rele12";  
